%**************************************************************************************************
%Reference:  
% S. X. Zhang, Y. H. Liu, J. T. Luo, L. M. Zheng, S. Y. Zheng, "Differential evolution with dimensionally adaptive inheritance"

% J. Zhang and A. C. Sanderson, "JADE: adaptive differential evolution
%                     with optional external archive," IEEE Trans. Evolut. Comput., vol. 13,
%                     no. 5, pp. 945-958, 2009.
%**************************************************************************************************
function [outcome]=PCM_DAI_JADE_rand1()

    clc;
    clear all;

    format long;
    format compact;

    func = [1,3:30];
    totalTime = 51;
    problem_size = 30;
    
for problem_size = problem_size

   for func = func
       
    func = func
    popsize = 100;
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];

    % Record the best results
    outcome = []; 

    rand('seed', sum(100 * clock));
    
    parfor time =1:totalTime
   
        % Initialize the main population
        popold = repmat(lu(1, :), popsize, 1) + rand(popsize, problem_size) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));

        valParents = cec17_func(popold',func);
        valParents = valParents';

        c = 1/10;
%         p = 0.05;

        CRm = 0.5;
        Fm = 0.5;

        Afactor = 1;

        archive.NP = Afactor * popsize; % the maximum size of the archive
        archive.pop = zeros(0, problem_size); % the solutions stored in te archive
        archive.funvalues = zeros(0, 1); % the function value of the archived solutions

        %% the values and indices of the best solutions
        [valBest, indBest] = sort(valParents, 'ascend');

        FES = 0;
        goodCR = []; goodF = [];
        while FES < problem_size * 10000 
            pop = popold; % the old population becomes the current population
            [valBest indBest] = sort(valParents, 'ascend');      
            std_p = std(pop);
            [~,idx_d] = sort(std_p);
            rank_d = zeros(1,problem_size);
            rank_d(idx_d) = 1:problem_size;
            rank_f = zeros(1,popsize);
            rank_f(indBest) = 1:popsize;     
 
            if FES > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
                CRm = (1 - c) * CRm + c * mean(goodCR);
                Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
            end

            % Generate CR according to a normal distribution with mean CRm, and std 0.1
            % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
            [F, CR] = randFCR(popsize, CRm, 0.1, Fm, 0.1);
            [~, CR2] = randFCR(popsize, CRm, 0.1, Fm, 0.1);
           
            r0 = [1 : popsize];
            [r1, r2, r3] = gnR1R2R3(popsize, r0);

            %  == == == == == = Mutation == == == == == == == == =
            vi  = pop(r1, :) + F(:, ones(1, problem_size)) .* (pop(r2, :) - pop(r3, :));
            vi = boundConstraint(vi, pop, lu);

            RATEo = 1 - rank_f'/popsize;
            rank_dA = repmat(rank_d,popsize,1);
            RATEoA = repmat(RATEo,1,problem_size);
            AA = rank_dA < problem_size * RATEoA;
            BB = rank_dA >= problem_size * RATEoA;
            cr = CR; cr2 = CR2;
            if mean(cr) > 0.7 
             crmin = max(cr,cr2);
             crmax = min(cr,cr2);
            else
             crmin = min(cr,cr2);
             crmax = max(cr,cr2);
            end
            CR1 = crmin(:, ones(1, problem_size));
            CR2 = crmax(:, ones(1, problem_size));
            CRd = CR1;
            CRd(AA) = CR1(AA);
            CRd(BB) = CR2(BB);
            % == == == == = Crossover == == == == =
            mask = rand(popsize, problem_size) > CRd; % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : popsize)'; cols = floor(rand(popsize, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([popsize problem_size], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop(mask);

            valOffspring = cec17_func(ui',func);
            valOffspring = valOffspring';
            FES = FES + popsize;

            % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
            [valParents, I] = min([valParents, valOffspring], [], 2);
            popold = pop;

            archive = updateArchive(archive, popold(I == 2, :), valParents(I == 2));

            popold(I == 2, :) = ui(I == 2, :);
            CR = mean(CRd,2);
            goodCR = CR(I == 2);
            goodF = F(I == 2);
            
        end
        minf = min(valParents) - 100 * func;
        outcome = [outcome minf];

%      fprintf('PCM_DAI_JADE_rand1_%d th run, best-so-far error value = %1.8e\n', time , minf)
    end
    fprintf('\n')
    fprintf('PCM_DAI_JADE_rand1_mean error value = %1.8e, std = %1.8e, min = %1.8e\n', mean(outcome), std(outcome), min(outcome))
    filename='PCM_DAI_JADE_rand1_cec17.xls';

%     if problem_size == 30
%     rowid = sprintf('A%d', func);
%     xlswrite(filename,sort(outcome),'D30',rowid); 
%     xlswrite(filename,[mean(outcome),std(outcome)],'D30mean&std',rowid); 
%     elseif problem_size == 50
%     rowid = sprintf('A%d', func);
%     xlswrite(filename,sort(outcome),'D50',rowid); 
%     xlswrite(filename,[mean(outcome),std(outcome)],'D50mean&std',rowid);
%     end
    end
end
end
